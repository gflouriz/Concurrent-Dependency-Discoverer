#ifndef _I_34_H_
#define _I_34_H_

#include <netinet/ip.h> /* defines in_addr */

#include "i_51.h"

#endif /* _I_34_H_ */
