#ifndef _I_50_H_
#define _I_50_H_

#include "i_35.h"
#include "i_28.h"
#include "i_45.h"
#include "i_44.h"
#include "i_46.h"
#ifndef EMBED_IN_KERNEL
#include <pthread.h>
#endif /* EMBED_IN_KERNEL */

#endif /* _I_50_H_ */
